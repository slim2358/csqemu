#include <stdio.h>

int main(int argc, char **argv)
{
	printf("RISC-V bare metal: hello\n");
    return 0;
}
